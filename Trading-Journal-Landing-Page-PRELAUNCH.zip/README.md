# Trading Journal — App Landing Page

Pre-launch landing page for **Trading Journal by TheMrPercent™**.

## Deploy in 5 minutes
1. Upload this repo to GitHub
2. Enable GitHub Pages (root)
3. Your site goes live instantly

Later:
- Add ios_app_id to `_config.yml` after App Store approval

Built for serious traders.
