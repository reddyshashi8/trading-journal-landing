---
title: Privacy Policy
include_in_header: false
---

## Privacy Policy

Trading Journal respects your privacy.

We collect only the data required to provide journaling, analytics, and AI coaching features.
We never connect to brokers or access your funds.

You may export or delete your data at any time.

Contact: support@themrpercent.com
