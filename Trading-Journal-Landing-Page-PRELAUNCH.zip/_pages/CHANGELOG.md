---
title: Changelog
include_in_header: true
---

## Beta Launch — 2025-12-27
- Pre-launch landing page
- Early access program opened
